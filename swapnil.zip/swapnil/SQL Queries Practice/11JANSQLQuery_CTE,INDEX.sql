create table make(
id int not null,
name varchar(30),
primary key(id)
)
-- make
create table model(
id int not null,
name varchar(30)not null,
price int not null,
year varchar(4)not null,
make_id int null,
primary key(id)
)
-- model

insert into make values(1,'maruthi'),(2,'toyata'),(3,'hyundai')
insert into model values(1,'i10',710000,'2018',1),(2,'i20',720000,'2018',2),(3,'alto',730000,'2018',3)
insert into model values(4,'i14',740000,'2018',1),(5,'i50',750000,'2018',2),(6,'alto10',760000,'2018',3)


-- employee_table
-- model
--make

-- CTE
--cte common table expression Two types
-- Non recursive
with data_employee_table (id,firstname,lastname)as
(select id,firstname,lastname from employee_table)

select * from data_employee_table

-- Recursive
with data_model (avg_price)as
(select avg(price) from model
)
select m.price,dm.avg_price from model m,data_model dm where m.price > dm.avg_price

-- join
select model.id,model.name,make.id as make_id,make.name as make_name 
from model
join make 
on make.id=model.make_id

--Recursive
with sample_cte as 
 (select id as model_id,name as model_name from model
 union all
 select make.id as make_id,make.name as make_name from make
 join model on model.make_id=make.id
 )
 select model_id,model_name from sample_cte


-- Table creation
 create table test_swapnil(id int,name varchar(20),address varchar(20),salary int)
insert into test_swapnil values(1,'abc','navi mumbai',100000),
(2,'pqe','Mumbai',1212312),(3,'xyz','panvel',4000000),(4,'qwe','thane',100000),(5,'zxc','vashi',500000)

insert into test_swapnil values(1,'abc','navi mumbai',110000),(5,'abc','navi mumbai',490000)




 -- Index
execute sp_helpindex model
execute sp_helpindex test_swapnil

ALTER INDEX Clusted_index_model  ON model  DISABLE;  -- It will disable index
ALTER INDEX ALL ON model DISABLE; -- It will disable all index
ALTER INDEX Clusted_index_model  ON model  REBUILD;  -- It will enable index 
ALTER INDEX ALL ON model REBUILD; -- It will enable all index


drop index if exists Clusted_index_model on model 
drop index if exists Clusted_index_swapnil on test_swapnil 

-- clustered index
 create clustered index Clusted_index_model
 on model(make_id asc)

create clustered index Clusted_index_swapnil
 on test_swapnil(id desc,salary asc)

 -- Non clusted index 
 create nonclustered index NonClusted_index_model
 on model(id desc)

 -- Filtered indexes
  create index Clusted_index_model_filtered
 on model(id asc) where id > 3
 




