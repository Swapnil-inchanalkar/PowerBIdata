-- SQL Wildcard Characters
/*A wildcard character is used to substitute one or more characters in a string.
Wildcard characters are used with the LIKE operator. The LIKE operator is used in a WHERE
clause to search for a specified pattern in a column.*/
 -- %=any no of character _=Single Character
create table wildChar(value_wildChar varchar(10));
drop table wildChar
ALTER TABLE wildChar ADD ID INT IDENTITY(1,1)
insert into wildChar(value_wildChar) values('abc'),('bcd'),('pqr'),('dca'),('asdf'),
      ('sdfg'),('dfgh'),('fghj'),('ghjk'),('hjkl');
insert into wildChar(value_wildChar) values('abc'),('adc'),('aec');
insert into wildChar(value_wildChar) values('aec'),('afc');

select * from wildChar where value_wildChar like'a%'
select * from wildChar where value_wildChar like'%a'
select * from wildChar where value_wildChar like'%a%'
select * from wildChar where value_wildChar like'a__'
select * from wildChar where value_wildChar like'__a'
select * from wildChar where value_wildChar like'd_a'
select * from wildChar where value_wildChar like'k______'
/*
Symbol Description Example
% Represents zero or more characters bl% finds bl, black, blue, and blob
_ Represents a single character h_t finds hot, hat, and hit
[] Represents any single character within the brackets h[oa]t finds hot and hat, but not hit
^ Represents any character not in the brackets h[^oa]t finds hit, but not hot and hat
- Represents any single character within the specified range c[a-b]t finds cat and cbt */
select * from wildChar where value_wildChar like'a[bd]c' -- Finds abc and adc
select * from wildChar where value_wildChar like'a[^bd]c' -- Finds not abc and adc
select * from wildChar where value_wildChar like'a[a-e]c' -- Finds in range a to e
select * from wildChar where value_wildChar like'[a-e]%' -- Finds value_wildChar starts from a to e
select * from wildChar where value_wildChar like'[a,e]%' -- Finds value_wildChar starts with a and e