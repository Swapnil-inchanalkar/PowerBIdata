select * from pf_test_table

select * from wip_test_table

select * from testtable4

select * from testtable5


drop table testtable1
drop table testtable2
drop table testtable3
drop table testtable4
drop table testtable5

select * from emp1_table
drop table prac12

create table prac12(
   id INT primary key,
   firstname varchar(50),
   lastname varchar(50),
   salary INT
   )



-- drop table designation_table
create table employee_table(id int primary key,firstname varchar(50) not null,lastname varchar(50) not null,
							address varchar(100) default ('Navi Mumbai'),age int check (age>18))
select * from employee_table
select * from designation_table;
select * from employee_department

create table designation_table(id int,
	designation varchar(25),
	foreign key(id) references employee_table(id))

create table employee_department(id int,
	department varchar(25))
	
insert into employee_table values(1,'swapnil','inchanalkar','Juinagar',21),
(2,'pratik','inchanalkar','nm',23),
(3,'Mahesh','lavate','Juinagar',22),
(4,'Aashish','shelear','Nerul',20)
insert into employee_table(id,firstname,lastname,age) values(6,'eric','D',22)

insert into designation_table values(1,'set'),(2,'manager'),(3,'Tc'),(4,'Devops')
insert into designation_table values(7,'ops')

insert into employee_department values(1,'IT'),(2,('Finance'))
insert into employee_department values(7,'Marketing'),(8,('HR'))

update employee_table set address='New address' where id=2
update employee_table set age=25 where firstname='Aashish'

delete from employee_table where id=6
delete from designation_table where id=1
truncate table destination
alter table destination add constraint id primary key

-- inner equi left right full outer natural self cartesion 
select e.id,firstname,lastname,address,age,d.designation from employee_table e,designation_table d where e.id=d.id
select e.id,firstname,lastname,address,age,d.designation from employee_table e inner join designation_table d on e.id=d.id

select e.id,firstname,lastname,address,age,d.designation from employee_table e left join designation_table d on e.id=d.id
select e.id,firstname,lastname,address,age,d.department from employee_table e right join employee_department d on e.id=d.id
select e.id,firstname,lastname,address,age,d.department from employee_table e full outer join employee_department d on e.id=d.id

select * from employee_table natural join employee_department;
select d1.id,d1.department from employee_department d1,employee_department d2 where d1.id >2 --self
select * from employee_table cross join employee_department



