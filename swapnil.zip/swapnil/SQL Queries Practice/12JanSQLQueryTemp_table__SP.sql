--Temp tables:Two types Local and Global
--local
create table #temp_table_swapnil(id int,name varchar(20))

insert into #temp_table_swapnil values(1,'swapnil'),(2,'sameer'),(3,'abhishek')

select * from #temp_table_swapnil

drop table #temp_table_swapnil



--Global
create table ##temp_table_swapnil_global(id int,Fullname varchar(20))

insert into ##temp_table_swapnil_global values(1,'swapnil inchanalkar'),
(2,'Pratik inchanalkar'),
(3,'aashish shelar'),
(4,'mahesh lavate')

select * from ##temp_table_swapnil_global

drop table ##temp_table_swapnil_global



-- SP
SELECT * FROM sys.procedures;

--EX1 Without parameters
create procedure procedure1
as
select * from test_swapnil

exec procedure1


--EX2 With parameter
create procedure procedure22 @name varchar(20)
as
begin
select * from test_swapnil where name=@name
end

exec procedure22 @name='zxc'


--EX3 With multiple parameters
create procedure proc3 @id int,@salary int
as 
begin
drop table if exists temp_table
select * from test_swapnil where id=@id or salary=@salary
end
exec proc3 @id=4,@salary=100000


--Ex
drop procedure if exists proc3
go
create procedure proc3 @id int,@salary int
as 
begin
drop table if exists temp_table
select * into temp_table from test_swapnil where id=@id or salary=@salary
select * from temp_table
end

exec proc3 @id=4,@salary=100000
select * from temp_table;

