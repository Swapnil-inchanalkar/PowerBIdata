drop table accountbalance
drop table account_payments
create table accountbalance(acc_no int,balance int)
create table account_payments(date varchar(20),acc_no int,payment int)
go
-- truncate table accountbalance
insert into accountbalance values(1,100),(2,150),(3,200),(4,250),(5,1000),(6,5000)
insert into account_payments values('2021',1,50),('2021',2,25),('2021',2,125),
('2021',3,100),('2021',4,50),('2021',5,500)

--Cursor
/*a cursor make it possible to define a result set (a set of data rows) and perform complex logic on a 
row by row basis.
*/
declare @acc_no int 
declare @payment decimal(18,2)
--Declare Curser
declare ex_cursor cursor for 
select acc_no,payment 
from dbo.account_payments

open ex_cursor
--Fetch the next record from the cursor
fetch next from ex_cursor into @acc_no,@payment --putting values into variables

-- Set the status for the cursor
while @@FETCH_STATUS=0 
begin
	update accountbalance
	set balance=balance-@payment
	where acc_no=@acc_no

	fetch next from ex_cursor into  @acc_no,@payment
end

close ex_cursor


-- deallocate ex_cursor

-- select * from accountbalance 