-- While Loop
DECLARE @i INTEGER;
SET @i = 1;
 
WHILE @i <= 10
BEGIN
   PRINT CONCAT('Pass...', @i);
   SET @i = @i + 1;
END;


--model
--EX
declare @count int,@id int =1, @name varchar(20)
select @count=COUNT(*) from model

while @id <= @count
begin 

	select @name=name from model where id=@id
	print concat(@id,' ',@name)
	set @id =@id+1
end

--
Declare @whileloop int
set @whileloop=1
create table #temp1 (id int)

while @whileloop<=100
begin
insert into #temp1
select @whileloop as num

set @whileloop=@whileloop+1
end