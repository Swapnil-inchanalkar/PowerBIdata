-- Conditional Statements if | if else | if else if | Nested Loop
-- IF Statement
declare @value_int int=100
if @value_int > 10
begin
 print 'value is greater than 10'
end

-- IF else Statement
declare @value_int int=-11
if @value_int < 0
begin
 print 'value is Negative'
end
else
begin
	print 'value is Positive'
end

-- IF else if Statement
declare @value_int int=-8
if @value_int < 0 
begin
	print 'value is Negative'
end
else if @value_int > 10
begin
 print 'value is greater than 10'
end
else if @value_int > 0 and @value_int < 10
begin
 print 'value is between 0 to 10'
end

-- Nested if else statment
declare @value_int int=11
if @value_int < 0
begin
 print 'value is Negative'
end
else
begin
 if @value_int > 0 and @value_int < 10
 begin
  print 'value is between 0 to 10'
 end
 else
 begin
  print 'value is Greater than 10'
 end
end
model

--Ex
create function func_ifelse(@id int)
returns table
as
return(select * from model where id=2)
go
select * from func_ifelse(2)

--Ex2 Not working
create function func_ifelse1(@id int)
returns table
as
if @id =2
begin
return(select * from model where id=2)
end
else if @id =3
begin
return(select * from model where id=3)
end
go
select * from func_ifelse1(2)

