-- over clause
create table rownumextable(id int,gender varchar(20),salary int)

insert into rownumextable values(1,'male',1000),
(2,'male',2000),
(3,'female',4000),
(4,'female',5000),
(5,'male',6000),
(6,'male',9000),
(7,'male',8000),
(8,'female',9000),
(9,'male',16000),
(15,'female',61000)

-- Aggergarte
select gender from rownumextable order by gender 
--
select gender,count(*) as TotalGender,AVG(salary) as AvgSal,MAX(salary) as MaxSal,min(salary) as MinSal
from rownumextable group by gender order by gender desc;

-- Query 
select salary,r.gender,genders.TotalGender, genders.AvgSal,genders.MinSal , genders.MaxSal
from rownumextable r
inner join
(select gender,count(*) as TotalGender,AVG(salary) as AvgSal,MAX(salary) as MaxSal,min(salary) as MinSal
from rownumextable group by gender) as genders
on genders.gender=r.gender


-- Query with over clause
-- use to reduce the number of lines
select id,salary,gender,
COUNT(gender) over (partition by gender)as GendersTotal 
from rownumextable

-- Ex2 over clause
select id,salary,gender,
COUNT(gender)over (partition by gender)as GendersTotal,
min(salary)over (partition by gender)as MinSalary,
max(salary)over (partition by gender)as MaxSalary 
from rownumextable

-- Row Num
/*The ROW_NUMBER() is a window function that assigns a sequential integer to each row within the partition 
of a result set. The row number starts with 1 for the first row in each partition.		*/
-- Without partition by
select id,salary,gender,
ROW_NUMBER() over (order by gender)as RowNumber
from rownumextable

-- With partition by
select id,salary,gender,
ROW_NUMBER() over (partition by gender order by gender)as RowNumber
from rownumextable

-- Without partition by and performing operations
with cte_rownum as (
select id,salary,gender,
ROW_NUMBER() over (order by gender) as RowNumber
from rownumextable)

select id,salary,gender,RowNumber from cte_rownum
 where RowNumber > 2 and RowNumber <=6

-- Rank Function

with cte_rank as(
select id,salary,gender,
ROW_NUMBER() over (order by salary)as RowNumber,
rank() over (order by salary)as [Rank], 
DENSE_RANK() over (order by salary)as [Dense Rank]
from rownumextable)


select * from cte_rank
  
