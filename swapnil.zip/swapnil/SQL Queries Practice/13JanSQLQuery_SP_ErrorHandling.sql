-- in out example Update
drop PROCEDURE if exists salary_Inc
go
CREATE PROCEDURE salary_Inc(@id int, @up_sal int out)
as
BEGIN
UPDATE test_swapnil SET salary = salary+1000 WHERE id =@id;
SELECT salary INTO temp_table2 FROM test_swapnil WHERE id =@id;
END;

declare @dup1 int
exec salary_Inc 1,@dup1 out 
select @dup1


--Done IN OUT
drop PROCEDURE if exists salary_Increment
go
CREATE PROCEDURE salary_Increment(@id int, @up_sal int out)
as
BEGIN
declare @sal int
SELECT @sal=salary FROM test_swapnil WHERE id =@id
set @up_sal=@sal*0.1 -- +10%
select * from test_swapnil
END;

declare @dup_sal int
exec salary_Increment 4,@dup_sal out
select @dup_sal


-- Error Handling
drop PROCEDURE if exists salary_Increment
go
CREATE PROCEDURE salary_Increment(@id int, @up_sal int out)
as
BEGIN
begin try
declare @sal int
SELECT @sal=salary FROM test_swapnil WHERE id =@id
set @up_sal=@sal/0 -- +10%
select * from test_swapnil
end try
begin catch
SELECT
    ERROR_NUMBER() AS ErrorNumber,
    ERROR_STATE() AS ErrorState,
    ERROR_SEVERITY() AS ErrorSeverity,
    ERROR_PROCEDURE() AS ErrorProcedure,
    ERROR_LINE() AS ErrorLine,
    ERROR_MESSAGE() AS ErrorMessage;
end catch
END;

declare @dup_sal int
exec salary_Increment 1,@dup_sal out
select @dup_sal

--
BEGIN TRY
   DECLARE @x int
   SELECT @x = 1/0

END TRY
BEGIN CATCH 
   Throw 50000,N'Error....',1;
      -- PRINT 'This statement will not be executed'
END CATCH
print @x

--
BEGIN TRY
   DECLARE @a int,@b int,@c int
   SELECT @a =10
   SELECT @b =0
   select @c=@a/@b
   END TRY
BEGIN CATCH 
   PRINT 'The error message is: ' + error_message()
end CATCH
print @c









