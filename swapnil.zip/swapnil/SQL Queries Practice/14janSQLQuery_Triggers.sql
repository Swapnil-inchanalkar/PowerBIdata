CREATE TABLE Employee_triggertbl
(  
  Id INT PRIMARY KEY,  
  Name VARCHAR(45),  
  Salary INT,  
  Gender VARCHAR(12),  
  DepartmentId INT  
)

INSERT INTO Employee_triggertbl VALUES (1,'swapnil', 2000, 'male', 3),  
(2,'pratik', 5000, 'male', 2),  
(3,'aashish', 25000, 'male', 1),  
(4,'mahesh', 7000, 'male', 2),  
(5,'eric', 6000, 'male', 3)  

select * from Employee_triggertbl; 

CREATE TABLE Employee_Audit_Test  
(    
Id int IDENTITY,   
Audit_Action text   
)  

select * from Employee_Audit_Test;


-- Triggers 

-- Drop 
drop trigger empTrigger1;
drop trigger emp_Ins_Trigger;

-- Enable Trigger
ENABLE TRIGGER emp_Ins_Trigger on Employee_triggertbl;
--All
ENABLE TRIGGER ALL ON Employee_triggertbl;
-- Disable Trigger
DISABLE TRIGGER emp_Ins_Trigger on Employee_triggertbl;

/*	Types of SQL Server Triggers
We can categorize the triggers in SQL Server in mainly three types:

A.Data Manipulation Language (DML) Triggers: On Table  :after and instead
B.Data Definition Language (DDL) Triggers: On database 
C.Logon Triggers: on server */


/*A. Table level DML
--1. After
CREATE TRIGGER schema_name.trigger_name  
ON table_name  
AFTER {INSERT | UPDATE | DELETE}  
AS  
   BEGIN  
      -- Trigger Statements  
      -- Insert, Update, Or Delete Statements  
   END  

--2. Instead
CREATE TRIGGER schema_name.trigger_name  
ON table_name  
INSTEAD OF {INSERT | UPDATE | DELETE}  
AS  
   BEGIN  
      -- trigger statements  
      -- Insert, Update, or Delete commands  
   END     
   
   */



-- After Table level

--After Insert Trigger
create trigger emp_Ins_Trigger
on Employee_triggertbl
after insert 
as 
begin 
  Declare @Id int  
  SELECT @Id = Id from inserted  
  INSERT INTO Employee_Audit_Test  
  VALUES ('New employee with Id = ' + CAST(@Id AS VARCHAR(10)))
end
-- Sample Insert query
INSERT INTO Employee_triggertbl VALUES (6,'Rajesh', 62000, 'Male', 3)

--After Delete Trigger
create trigger emp_Del_Trigger
on Employee_triggertbl
after delete 
as 
begin 
  Declare @Id int  
  SELECT @Id = Id from deleted  
  INSERT INTO Employee_Audit_Test  
  VALUES ('An existing employee with Id = ' + CAST(@Id AS VARCHAR(10)))
end
-- Sample delete query
DELETE FROM Employee_triggertbl WHERE Id = 2;  

-- After update trigger
create trigger emp_Up_Trigger
on Employee_triggertbl
after update 
as 
begin 
  Declare @Id int  
  SELECT @Id = Id from inserted  
  INSERT INTO Employee_Audit_Test  
  VALUES ('Updated employee with Id = ' + CAST(@Id AS VARCHAR(10)))
end
--sample update query
update Employee_triggertbl set name='swapnil' where id=1


--Instead Table level
-- Instead 
CREATE TRIGGER instead_trigger_in ON Employee_triggertbl
INSTEAD OF insert
AS
BEGIN
  Select 'Sample Instead of trigger' as [Message]
END

--Insert
INSERT INTO Employee_triggertbl VALUES (7,'mayur', 6000, 'Male', 1)


--B.Data Definition Language (DDL) Triggers: On database 
CREATE TABLE TableSchemaChanges (ChangeEvent xml, DateModified datetime)

-- Trigger 
CREATE TRIGGER TR_ALTERTABLE ON DATABASE
FOR ALTER_TABLE
AS
BEGIN 
INSERT INTO TableSchemaChanges
SELECT EVENTDATA(),GETDATE()
END
 
--Table
create table triggersExTable_Audit(
DateOf_IUD datetime
);


-- trigger After insert update and delete
drop trigger if exists TriggerEx
CREATE TRIGGER TriggerEx
   ON Employee_triggertbl
   AFTER INSERT,DELETE,UPDATE
AS
BEGIN
 insert into triggersExTable_Audit VALUES(GETDATE())
END
GO

-- Sample Insert query
INSERT INTO Employee_triggertbl VALUES (7,'mubs', 60000, 'Male', 2)
