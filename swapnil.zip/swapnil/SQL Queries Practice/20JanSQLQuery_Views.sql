--Views
/*Views in SQL are kind of virtual tables. A view also has rows and columns as they are in a real table
in the database. We can create a view by selecting fields from one or more tables present in the database. 
A View can either have all the rows of a table or specific rows based on certain condition.
CREATE VIEW view_name AS
SELECT column1, column2.....
FROM table_name
WHERE condition; */

-- Creating View
create view TestSwapnil_view as 
select * from test_swapnil 
where id in (1,2,3,4)

select * from TestSwapnil_view

insert into TestSwapnil_view values(5,'qwer','Thane',90000)

update TestSwapnil_view set name='swapnil' where id=1

delete from test_swapnil where id=5

-- select * from make 
-- select * from model

create view make_model_Views as 
select model.id,model.name as model_name,model.price,model.make_id,make.name 
from model,make  
where make.id=model.make_id

--Drop View
drop view make_model_Views

--Update View
create or alter view make_model_Views as 
select model.id,model.name as model_name,model.price,model.make_id,make.name,model.year
from model,make  
where make.id=model.make_id

sp_helptext make_model_Views



-- Transactions test_swapnil
begin transaction
 insert into test_swapnil values(6,'ABC','NM',200000)
 save transaction InsertStatement
 delete from test_swapnil where id=6
 select * from test_swapnil
 ROLLBACK TRANSACTION InsertStatement
 select * from test_swapnil
 commit transaction
 rollback transaction

 --Named Transaction in SQL
 begin transaction addvalue
 insert into test_swapnil values(7,'ABCD','NM',1200000)
 commit transaction


 --TCL commands
 begin transaction
 insert into test_swapnil values(8,'ABCDE','Navi Mumbai',210000)
 save transaction InsertStatement
 select * from test_swapnil
 delete from test_swapnil where id=8
 select * from test_swapnil
 save transaction DeleteStatement
 ROLLBACK TRANSACTION DeleteStatement
 select * from test_swapnil
 commit transaction




