select * from swapniltesttable2

select * from testtable2


-- drop table emp2;
create table emp1(id INT primary key,firstname varchar(50),lastname varchar(50),salary INT)
insert into emp1(ID,firstname,lastname,salary) 
values(1,'SWAPNIL','INCHANALKAR',10000),
(2,'PRATIK','INCHANALKAR',20000),
(3,'MAHESH','LAVATE',40000),
(4,'AASHISH','SHELAR',50000)

create table emp2(id INT primary key,firstname varchar(50),lastname varchar(50),salary INT)
insert into emp2(ID,firstname,lastname,salary) 
values(1,'rohit','gaikwad',10000),
(2,'Prashant','Ingale',20000),
(3,'Mayur','katkar',40000),
(4,'vaibhav','mourya',50000)

create table emp2(id INT primary key,firstname varchar(50),lastname varchar(50),salary INT)
insert into emp2(ID,firstname,lastname,salary) 
values(1,'rohit','gaikwad',10000),
(2,'Prashant','Ingale',20000),
(3,'Mayur','katkar',40000),
(4,'vaibhav','mourya',50000)

create table emp2(id INT primary key,firstname varchar(50),lastname varchar(50),salary INT)
insert into emp2(ID,firstname,lastname,salary) 
values(1,'rohit','gaikwad',10000),
(2,'Prashant','Ingale',20000),
(3,'Mayur','katkar',40000),
(4,'vaibhav','mourya',50000)

create table emp2(id INT primary key,firstname varchar(50),lastname varchar(50),salary INT)
insert into emp2(ID,firstname,lastname,salary) 
values(1,'rohit','gaikwad',10000),
(2,'Prashant','Ingale',20000),
(3,'Mayur','katkar',40000),
(4,'vaibhav','mourya',50000)

create table emp3(id INT primary key,firstname varchar(50),lastname varchar(50),salary INT)
insert into emp3(ID,firstname,lastname,salary) 
values(1,'parmesh','s',10000),
(2,'vinod','washiwale',20000),
(3,'rajesh','yadav',40000),
(4,'rohit','chorge',50000)

create table emp4(id INT primary key,firstname varchar(50),lastname varchar(50),salary INT)
insert into emp4(ID,firstname,lastname,salary) 
values(1,'rohit','katkar',10000),
(2,'pratk','Ingale',20000),
(3,'Mayur','sargar',40000),
(4,'mohit','mourya',50000)

create table emp5(id INT primary key,firstname varchar(50),lastname varchar(50),salary INT)
insert into emp5(ID,firstname,lastname,salary) 
values(1,'rohan','gaikwad',10000),
(2,'Prashant','kale',20000),
(3,'mahesh','katkar',40000),
(4,'vaibhav','gaikwad',50000)

select * from emp1
select * from emp2
select * from emp3
select * from emp4
select * from emp5

























