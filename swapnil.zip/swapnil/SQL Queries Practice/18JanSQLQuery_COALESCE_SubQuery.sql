-- COALESCE
SELECT COALESCE (NULL,'A','B')
SELECT COALESCE (NULL,100,20,30,40)
SELECT COALESCE (NULL,NULL,20,NULL,NULL)
SELECT COALESCE (NULL,NULL,NULL,NULL,NULL,'swapnil')
SELECT COALESCE (NULL,NULL,NULL,NULL,1,'swapnil')


-- Subquery
create table accountbalance_SQ(acc_no int,balance int)
create table account_payments_SQ(date varchar(20),acc_no int,payment int)
go
-- truncate table account_payments_SQ
insert into accountbalance_SQ values(1,100),(2,150),(3,200),(4,250),(5,1000),(6,5000)
insert into account_payments_SQ values('2020',1,50),('2021',2,25),('2022',2,125),
('2011',3,100),('2028',4,50),('2019',5,500)

--
select 
acc_no,balance,
(select max(date) from account_payments_SQ 
where account_payments_SQ.acc_no=accountbalance_SQ.acc_no) as date 
from accountbalance_SQ

select * from make
select * from model
--
select 
id,name 
from model where id in (select id from make where name='toyata' or name='maruthi')
--
select 
id,name 
from model where id not in (select id from make where name='toyata' or name='maruthi')
--
select id,name from make where id =(select min(make_id) from model)


-- Case statement
--Types :simple searched
/*Simple Case	
CASE keyword is immediately followed by CASE_Expression and before WHEN statement.
E.g.:
CASE <Case_Expression>
WHEN Value_1 THEN Statement_1�   */

/*Searched case
Case keyword is followed by the WHEN statement, and there is no expression between CASE and WHEN.
E.g.:
CASE WHEN <Boolean_Expression_1> THEN Statement_1� */

select id ,name,
case
 when price > 750000 then 'Greater than 750000'
 when price =750000 then 'Equal to 750000'
 else 'Less than 750000' 
end as values_model
from model

-- Simple case Ex
select id,name,price,make_id 
from model 
order by 
case make_id
	when 1 then price end desc,
case when make_id=2 then price end

 -- Searched case Ex
select id ,name,
case
 when price > 750000 then 'Greater than 750000'
 when price =750000 then 'Equal to 750000'
 when price <750000 then 'Less than 750000' 
 else 'Value is null'
end as values_model
from model

--
declare  @id int
set @id=4
select case @id 
when 1 then 'One'
when 2 then 'two'
when 3 then 'three'
when 4 then 'Four'
else 'Nulll'
end


