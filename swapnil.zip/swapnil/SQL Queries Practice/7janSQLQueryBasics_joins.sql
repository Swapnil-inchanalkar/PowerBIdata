-- drop table designation
create table employee_table(id int primary key,firstname varchar(50) not null,lastname varchar(50) not null,
	address varchar(100) default="navi mumbai",age int check(age > 18))

insert into employee_table values(1,'swapnil','inchanalkar','juinagar',21)

create table employee_department(id int,department varchar(20),foreign key(id) references employee_table(id))

create table designation_table(id int unique,designation varchar(20))

insert into designation_table values(1,'set'),(2,'manager'),(3,'TS'),(4,'Devops')

update employee_table set age=25 where id=4;
update employee_table set address='New address' where firstname='pratik';

delete from employee_table where id=1;
delete from employee_table where firstname='mahesh';
delete from designation_table where id=2


select * from employee_table
select * from employee_department
select * from designation_table


select e.id,firstname,lastname,address,age,d.ID from employee_table e,employee_department d where e.id=d.id;
select * from employee_table e equi join employee_department d where e.id=d.id;
select e.id,firstname,lastname,address,age,d.ID from employee_table e inner join employee_department d on e.id=d.id;

select e.id,firstname,lastname,address,age,d.ID from employee_table e left join employee_department d on e.id=d.id;
select e.id,firstname,lastname,address,age,d.ID from employee_table e right join employee_department d on e.id=d.id;
select e.id,firstname,lastname,address,age,d.ID from employee_table e full outer join employee_department d on e.id=d.id;
select d1.id from designation_table d1,designation_table d2 where d2.id <= 5 ; -- self
