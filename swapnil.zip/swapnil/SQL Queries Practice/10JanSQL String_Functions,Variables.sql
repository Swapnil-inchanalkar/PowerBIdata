-- SQL String functions
select ASCII('sample')
select ASCII('sample12')
select len('sample')
select len('sample word')
select concat('swapnil',' ','inchanalkar',' ','124')
select upper('swapnil inchanalkar')
select LOWER('SWAPNIL')
select LEFT('swapnil',5)
select right('swapnil inchanalkar',2)
select reverse('swapnil')
select RTRIM('swapnil')

select (firstname+' '+lastname)as fullname from employee_table
select ascii(firstname) from employee_table
select char(65)

--Example1
SELECT lastname,max(age) FROM employee_table group by lastname

--Example2
select lastname from employee_table group by lastname having count(lastname) >1;

--Variable
declare @var_id as int =5
print @var_id

declare @name varchar(10),@age as int

declare @id_fromemptable as int
set  @id_fromemptable= (select id from employee_table where firstname='eric' )
print @id_fromemptable

declare @id as int
set  @id=6
select firstname from employee_table where id= @id













