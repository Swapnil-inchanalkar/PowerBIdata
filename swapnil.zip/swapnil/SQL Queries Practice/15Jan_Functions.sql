-- Functions
#IN BUILD FUNCTIONS
SELECT POWER(2,3) AS POWER;
SELECT SQUARE(4) AS SQUARE;
SELECT ABS(-34.2) AS ABSOLUTE;
#WITH DECLARATION ABSOLUTE FUNCTIONS
DECLARE @I INT
SET @I = -24.5
SELECT ABS(@I) AS [ABSOLUTE VALUE];
--USER DEFINED FUNCTIONS
-- ADDITION Without prarmeter
drop function if exists ADDITIONWP
go
CREATE function ADDITIONWP()
RETURNS INT
AS
BEGIN
DECLARE @x INT=10,@y int =20
DECLARE @RESULT INT= @X+@Y
RETURN @RESULT
END
go
SELECT dbo.ADDITIONWP() AS ADDITION;
-- ADDITION
drop function if exists ADDITION
go
CREATE function ADDITION(@X INT,@Y INT)
RETURNS INT
AS
BEGIN
DECLARE @RESULT INT= @X+@Y
RETURN @RESULT
END
go
SELECT DBO.ADDITION(10,20) AS ADDITION;
--SUBSTRACTION
drop function if exists SUB
go
CREATE function SUB(@X INT,@Y INT)
RETURNS INT
AS
BEGIN
DECLARE @RESULT INT= @X-@Y
RETURN @RESULT
END
go
SELECT DBO.SUB(10,20) AS SUBSTRACTION;
-- Example Without Functions
declare @dob date
declare @age int
set @dob='04-16-2001'
set @age =DATEDIFF(year,@dob,GETDATE())
select @age
--Scalar function Types #Without prarameter #with parameter #with where Clause
drop function functionage
create function functionage(@dob date)
returns int
as
begin
 declare @age int
set @age =DATEDIFF(day,@dob,GETDATE())
return @age
end

select dbo.functionage('2001')
select GETDATE()
--make
--Table Valued Functions ex1
drop function if exists tableValuedFunction
go
create function tableValuedFunction(@id int)
returns table
as
return(select * from make where id=@id)
go
select * from dbo.tableValuedFunction(2)

--Table Valued Functions ex2
drop function if exists tableValuedFunction2
go
create function tableValuedFunction2(@EnglishDayNameOfWeek nvarchar(10))
returns table
as
return(select * from dimdate where EnglishDayNameOfWeek=@EnglishDayNameOfWeek)
go
select * from dbo.tableValuedFunction2('sunday')


--Multi statement table valued functions
drop function if exists tableValuedFunction3
go
create function tableValuedFunction3()
returns @table table (id int ,gender nvarchar(10))
as
begin
 insert into @table
 select id,gender from rownumextable
return
end
go
select * from dbo.tableValuedFunction3()
